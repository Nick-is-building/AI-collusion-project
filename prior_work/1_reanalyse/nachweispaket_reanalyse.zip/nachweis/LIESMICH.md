# Nachweispaket zur Reanalyse von Shi et al. (2609.24967)

Stand 23.10.2026. Ziel: Jede Zahl aus den Runden 4 bis 7 laesst sich ohne Download nachrechnen.

Start: `python pruefe_alles.py` im entpackten Ordner (benoetigt pandas). Laufzeit etwa 10 Sekunden.

| Datei | Inhalt |
|---|---|
| pruefe_alles.py | rechnet A bis D nach und vergleicht mit den genannten Werten |
| urteile_alle_53_bedingungen.csv | 53.000 Urteile aus allen 53 Bedingungen (Grundlage der Trennschaerfe) |
| urteile_reanalyse.csv | 4.000 Urteile mit strengen Uebertragungsindikatoren (4 Bedingungen) |
| stichprobe_uebertragung.jsonl | 60 Originalbeispiele mit Rohlog und Nachrichten im Wortlaut (je 10 voll / fast voll / teilweise pro Modell, Zufallsauswahl Seed 42) |
| kosten_aufrufe_12_traces.csv | Token- und Kostenangaben aller 2.984 Modellaufrufe aus 12 Traces |
| trennschaerfe_alle_bedingungen.csv | Ergebnistabelle mit Bootstrap-Intervallen |
| reanalyse_shi.py | Skript, das die CSVs aus den Parquet-Dateien erzeugt |
| pruefsummen_reanalyse.txt | Datensatz-Revision, Code-Commit, Pruefsummen der Eingabedateien |
| quell_pruefsummen_53_episodentabellen.txt | SHA-256 der 53 Original-Episodentabellen |
| paket_pruefsummen.txt | SHA-256 aller Paketdateien |

Was das Paket nicht beweisen kann: dass die CSVs korrekt aus den Original-Parquets extrahiert wurden.
Dafuer: Parquets von huggingface.co/datasets/SALT-NLP/agent-collusion (Revision siehe pruefsummen_reanalyse.txt)
laden, Pruefsummen vergleichen, reanalyse_shi.py laufen lassen.
