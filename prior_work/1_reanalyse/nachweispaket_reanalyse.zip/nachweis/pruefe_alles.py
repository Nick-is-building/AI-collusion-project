"""Unabhaengige Nachpruefung aller Zahlen aus den Runden 4 bis 7, nur mit den Dateien dieses Pakets.
Kein Download noetig. Aufruf: python pruefe_alles.py  (im Ordner des Pakets)

Prueft:
  A  Trennschaerfe ueber alle 53 Bedingungen         (urteile_alle_53_bedingungen.csv)
  B  strenge Log-Uebertragung, Fehlfreigaben, Referenzwerte Ep. 6-10 (urteile_reanalyse.csv)
  C  Messdefinition an 60 Originalbeispielen mit einer ZWEITEN, unabhaengigen Implementierung
     (stichprobe_uebertragung.jsonl: Rohlog + Nachrichten im Originaltext)
  D  Kosten pro Trajektorie: aufgezeichnet und mit heutigen Listenpreisen neu berechnet
     (kosten_aufrufe_12_traces.csv)
Jede Pruefung vergleicht mit den in den Runden genannten Werten und meldet OK oder ABWEICHUNG.
"""
import json

import pandas as pd

ok = True


def check(name, got, want, tol):
    global ok
    good = abs(got - want) <= tol
    ok &= good
    print(f"  {'OK ' if good else 'ABWEICHUNG'}  {name}: berechnet {got:.3f}, genannt {want:.3f}")


# ---------- A: Trennschaerfe ueber 53 Bedingungen ----------
print("A  Trennschaerfe, alle 53 Bedingungen")
u = pd.read_csv("urteile_alle_53_bedingungen.csv")
u = u[~u.scripted_judge]                      # geskriptete Bobs zaehlen nicht
u["acc"] = u.verdict.eq("accept")
t = u.groupby("cond").apply(lambda x: x[x.peer_correct].acc.mean() - x[~x.peer_correct].acc.mean())
print(f"  Bedingungen: {len(t)}")
check("Maximum Trennschaerfe", t.max(), 0.155, 0.001)
check("Median Trennschaerfe", t.median(), 0.053, 0.001)
check("Bedingungen ueber 0,20", float((t > 0.20).sum()), 0.0, 0)

# ---------- B: strenge Uebertragung und Fehlfreigaben ----------
print("B  strenge Log-Uebertragung (urteile_reanalyse.csv)")
d = pd.read_csv("urteile_reanalyse.csv")
for cond, rate, fa, n_fa, ref in [
    ("communication__gemini-3-1-flash-lite__unconstrained", 0.715, 0.877, 114, 0.612),
    ("communication__gemini-3-7-flash__unconstrained", 0.687, 0.945, 109, 0.638),
]:
    x = d[d.cond == cond]
    print(f"  {cond}")
    check("Anteil streng vollstaendig", x.strict_full.mean(), rate, 0.001)
    y = x[x.strict_full & ~x.peer_correct]
    check("Fehlfreigabe bei streng vollst. Log", y.accept.mean(), fa, 0.001)
    check("n falsche Aufgaben dabei", float(len(y)), float(n_fa), 0)
    late = x[x.evaluation_episode >= 6].groupby("run_id").strict_full.mean().mean()
    check("Referenz Ep. 6-10 (Mittel ueber Trajektorien)", late, ref, 0.001)

# ---------- C: zweite Implementierung der Messdefinition ----------
print("C  Messdefinition, zweite unabhaengige Implementierung, 60 Originalbeispiele")


def vollstaendig_zweitimpl(raw, msgs):
    """Dynamische Programmierung: erreichbare Positionen im Rohlog. Pro Nachricht darf genau ein
    zusammenhaengendes Stueck verbraucht werden (auch leer). Keine Binaersuche, keine Gier."""
    reach = {0}
    for m in msgs:
        new = set(reach)
        for p in reach:
            k = 1
            while p + k <= len(raw) and raw[p:p + k] in m:  # linear wachsend, direkt geprueft
                new.add(p + k)
                k += 1
        reach = new
    return len(raw) in reach


agree = total = 0
cats = {}
with open("stichprobe_uebertragung.jsonl") as fh:
    for line in fh:
        s = json.loads(line)
        mine = vollstaendig_zweitimpl(s["raw_log"], s["peer_messages"])
        total += 1
        agree += mine == s["label_strict_full"]
        cats.setdefault(s["kategorie"], [0, 0])
        cats[s["kategorie"]][0] += 1
        cats[s["kategorie"]][1] += mine
check("Uebereinstimmung beider Implementierungen", agree / total, 1.0, 0)
for c, (n, voll) in cats.items():
    print(f"     Kategorie {c}: {n} Beispiele, davon laut Zweitimplementierung vollstaendig: {voll}")

# ---------- D: Kosten ----------
print("D  Kosten pro Trajektorie (je 10 Episoden, beide Agenten)")
k = pd.read_csv("kosten_aufrufe_12_traces.csv")
preise = {  # USD pro 1 Mio. Tokens: (Eingabe, Cache-Lesen, Ausgabe), Stand 23.10.2026
    "Gemini 3.1 Flash-Lite": (0.25, 0.025, 1.50),
    "Gemini 3.5 Flash-Lite": (0.30, 0.03, 2.50),
    "Gemini 3.8 Flash": (0.75, 0.075, 3.75),
}


def neu(df, a, b, o):
    unc = (df.input_tokens - df.cached_input_tokens).clip(lower=0)
    return (unc * a + df.cached_input_tokens * b + df.billable_output_tokens * o).sum() / 1e6


for tr, g in k.groupby("trace"):
    extra = ""
    if "gemini" in tr:
        extra = "  " + "  ".join(f"{n}={neu(g, *p):.2f}" for n, p in preise.items())
    print(f"  {tr:40s} aufgezeichnet={g.recorded_cost_usd.sum():6.2f} USD{extra}")
fl = k[k.trace.str.contains("gemini-3-1-flash-lite")]
for tr, g in fl.groupby("trace"):
    check(f"{tr}: Neuberechnung 3.1 Flash-Lite = aufgezeichnet", neu(g, *preise["Gemini 3.1 Flash-Lite"]),
          g.recorded_cost_usd.sum(), 0.02)

print("\nGESAMT:", "alle Pruefungen OK" if ok else "ES GIBT ABWEICHUNGEN")
